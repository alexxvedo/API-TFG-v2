package com.example.api_v2.model;

public enum FlashcardStatus {
    PENDING,
    ACTIVE,
    SUSPENDED,
    ARCHIVED
}
