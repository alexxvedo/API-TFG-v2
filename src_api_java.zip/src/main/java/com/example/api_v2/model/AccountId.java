package com.example.api_v2.model;

import java.io.Serializable;

public class AccountId implements Serializable {
    private String provider;
    private String providerAccountId;
}

