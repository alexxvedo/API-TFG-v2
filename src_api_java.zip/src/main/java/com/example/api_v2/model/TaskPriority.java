package com.example.api_v2.model;

public enum TaskPriority {
    LOW,
    MEDIUM,
    HIGH
}
