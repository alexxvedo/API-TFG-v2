package com.example.api_v2.model;

public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    DONE
}
