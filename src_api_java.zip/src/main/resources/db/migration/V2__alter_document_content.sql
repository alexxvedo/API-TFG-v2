-- Modify content column to use TEXT type
ALTER TABLE documents ALTER COLUMN content TYPE TEXT;
