package com.example.api_v2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiV2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
